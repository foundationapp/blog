<?php

namespace Foundationapp\Blog;

class Blog
{
    // Build your next great package.
}
